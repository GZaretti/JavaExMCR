package reduces;

public interface IReduce {
    public double getReduction(double price);
    public double getPrice(double price);
}
